# Blog Informativo
Integrantes: 
- Juan de Dios Ramírez Campos
- José Manuel Martínez García

# Descripción

# Tiempo

# Requerimientos

# Requerimientos

- SSH
- Seguridad:
- https
- Certificado para https
- Puertos abiertos:
- 80 (Nginx)
- 443 (Nginx)
- 8080 (local)
- 3306 (MySQL)
- Nginx
- Node JS -> v20.13.1
- Angular -> v17.1.0
- MySQL Community -> v8.4.0
- Tamaño de memoria: 50G 
- Zoma horaria America/Mexico_City 
- Respaldar cada 3 días

 https://chat.whatsapp.com/LjzfcvzXQuS3b97EykVdEV

